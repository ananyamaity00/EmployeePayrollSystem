# Employee Payroll System

A simple Java program to manage and display employee payroll information based on hourly rate and hours worked.

## Features
- Accepts multiple employees' input
- Calculates total salary based on hourly rate and hours worked
- Nicely formatted console output

## How to Run

### Compile:
```
javac src/*.java
```

### Run:
```
java src.EmployeePayrollSystem
```

## Author
Payel Maity
